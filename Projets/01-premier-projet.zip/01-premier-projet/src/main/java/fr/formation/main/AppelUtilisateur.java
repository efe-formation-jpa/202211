package fr.formation.main;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import fr.formation.entity.Utilisateur;

public class AppelUtilisateur {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("H2_PU");
		EntityManager em = emf.createEntityManager();
		
		Utilisateur u1 = new Utilisateur(1, "login1", "pwd1");
		Utilisateur u2 = new Utilisateur(2, "login2", "pwd2");
		Utilisateur u3 = new Utilisateur(3, "login3", "pwd3");
		Utilisateur u4 = new Utilisateur(4, "login4", "pwd4");
		

		EntityTransaction et = em.getTransaction();
		et.begin();
		
		try {
			em.persist(u1);
			em.persist(u2);
			em.persist(u3);
			em.persist(u4);
			
			System.out.println("OK");
			et.commit();
		}
		catch(Exception e) {
			System.out.println("Pas OK : " + e.getMessage());
			et.rollback();
		}
		
		String requete = "Select Object(u) from Utilisateur u";
		List<Utilisateur> listeU = em.createQuery(requete, Utilisateur.class).getResultList();
		System.out.println("Liste des utilisateurs en base : ");
		listeU.forEach(u -> System.out.println(u));
				
		em.close();
		emf.close();
	}
}
