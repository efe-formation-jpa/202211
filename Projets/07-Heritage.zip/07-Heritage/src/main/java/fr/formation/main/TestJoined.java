package fr.formation.main;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import fr.formation.bean.joined.Berline;
import fr.formation.bean.joined.Voiture;
import fr.formation.bean.joined.VoitureDeCourse;





public class TestJoined {

	public static void main(String[] args) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("MySql_PU");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		
		Voiture v = new Voiture("Char d'Assaut");
		Berline b = new Berline("Tesla", "Or");
		VoitureDeCourse vdc = new VoitureDeCourse("4L", "Trophy Royal 4L");
		
		et.begin();
		
		try {
			em.persist(v);
			em.persist(b);
			em.persist(vdc);
			et.commit();
		} catch (Exception e) {
			et.rollback();
			e.printStackTrace();
		}
		
		System.out.println("Liste des berlines :");
		List<Berline> listeB = em
								.createQuery("Select Object(b) from BerlineJoinedEntity b", Berline.class)
								.getResultList();
		for (Berline be : listeB) {
			System.out.println(be);
		}
	
		
		System.out.println("Liste des voitures :");
		List<Voiture> listeV = em
								.createQuery("Select Object(v) from VoitureJoinedEntity v", Voiture.class)
								.getResultList();
		for (Voiture voiture : listeV) {
			System.out.println(voiture);
		}
	
		em.close();
		emf.close();
	}

}
