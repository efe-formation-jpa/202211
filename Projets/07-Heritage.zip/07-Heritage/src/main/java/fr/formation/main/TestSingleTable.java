package fr.formation.main;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import fr.formation.bean.single.Berline;
import fr.formation.bean.single.Voiture;
import fr.formation.bean.single.VoitureDeCourse;

public class TestSingleTable {

	public static void main(String[] args) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("MySql_PU");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		
		Voiture v = new Voiture("Lada");
		Berline b = new Berline("Audi", "Camouflage");
		VoitureDeCourse vdc = new VoitureDeCourse("Renault", "Renault Sport");
		
		et.begin();
		
		try {
			em.persist(v);
			em.persist(b);
			em.persist(vdc);
			et.commit();
		} catch (Exception e) {
			et.rollback();
			e.printStackTrace();
		}
		
		System.out.println("Liste des berlines :");
		List<Berline> listeB = em
								.createQuery("Select Object(b) from Berline b", Berline.class)
								.getResultList();
		for (Berline be : listeB) {
			System.out.println(be);
		}
	
		
		System.out.println("Liste des voitures :");
		List<Voiture> listeV = em
								.createQuery("Select Object(v) from Voiture v", Voiture.class)
								.getResultList();
		for (Voiture voiture : listeV) {
			System.out.println(voiture);
		}
	
		
		System.out.println("Liste des voitures 'Voiture' :");
		List<Voiture> listeVV = em
								.createQuery("SELECT Object(v) FROM Voiture v WHERE DISCR='V'", Voiture.class)
								.getResultList();
		for (Voiture voiture : listeVV) {
			System.out.println(voiture);
		}
	
		em.close();
		emf.close();
	}

}
