package fr.formation.bean.tableperclass;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity(name="BerlineTPCEntity")
@Table(name="TPCBerline")
public class Berline extends Voiture {
	private static final long serialVersionUID = 1L;
	
	private String couleurCuir;

	public Berline() {
		super();
	}
	
	public Berline(String marque, String couleurCuir) {
		super(marque);
		this.couleurCuir = couleurCuir;
	}
	
	public String getCouleurCuir() {
		return couleurCuir;
	}

	public void setCouleurCuir(String couleurCuir) {
		this.couleurCuir = couleurCuir;
	}

	@Override
	public String toString() {
		return "Berline [couleurCuir=" + couleurCuir + ", " + super.toString() + "]";
	}
	
	
}
