package fr.formation.bean.joined;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity(name="BerlineJoinedEntity")
@Table(name="JoinedBerline")
@DiscriminatorValue(value="B")
public class Berline extends Voiture {
	private static final long serialVersionUID = 1L;
	
	private String couleurCuir;

	public Berline() {
		super();
	}
	
	public Berline(String marque, String couleurCuir) {
		super(marque);
		this.couleurCuir = couleurCuir;
	}
	
	public String getCouleurCuir() {
		return couleurCuir;
	}

	public void setCouleurCuir(String couleurCuir) {
		this.couleurCuir = couleurCuir;
	}

	@Override
	public String toString() {
		return "Berline [couleurCuir=" + couleurCuir + ", " + super.toString() + "]";
	}
	
	
}
