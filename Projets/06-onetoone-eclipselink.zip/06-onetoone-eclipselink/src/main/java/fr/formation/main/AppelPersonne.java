package fr.formation.main;

import java.util.List;

import fr.formation.dao.JpaUtil;
import fr.formation.dao.PersonneDao;
import fr.formation.entity.Adresse;
import fr.formation.entity.Personne;

public class AppelPersonne {

	public static void main(String[] args) {
		
		Adresse a1 = new Adresse("44000", "Nantes");
		Adresse a2 = new Adresse("75001", "Paris");
		
		Personne p1 = new Personne("Lebleu", "Suzon", a1);
		Personne p2 = new Personne("Levert", "Aline", a2);
		
		
		PersonneDao pDao = new PersonneDao();
		pDao.add(p1);
		pDao.add(p2);
		
		List<Personne> listeP = pDao.findAll();
		System.out.println("\nListe des personnes en base :");
		listeP.forEach(p -> System.out.println(p));
		
		List<Adresse> listeA = pDao.findAllAdresses();
		System.out.println("\nListe des adresses en base :");
		listeA.forEach(a -> System.out.println(a));
		
		// Modif 1
		p1.setPrenom("Suzanne");
		p1.getAdresse().setCodePostal("44100");
		pDao.update(p1);
		listeP = pDao.findAll();
		System.out.println("\nListe des personnes en base apres modif 1 :");
		listeP.forEach(p -> System.out.println(p));
		
		// Modif 2
		p2.setNom("LeRouge");
		Adresse a3 = new Adresse("29000", "Quimper");
		p2.setAdresse(a3);
		pDao.update(p2);
		listeP = pDao.findAll();
		System.out.println("\nListe des personnes en base apres modif 2 :");
		listeP.forEach(p -> System.out.println(p));

		// Suppression de p1
		pDao.delete(p1);
		listeP = pDao.findAll();
		System.out.println("\nListe des personnes en base apres supp de p1 :");
		listeP.forEach(p -> System.out.println(p));
		
		
		JpaUtil.close();
	}
}
