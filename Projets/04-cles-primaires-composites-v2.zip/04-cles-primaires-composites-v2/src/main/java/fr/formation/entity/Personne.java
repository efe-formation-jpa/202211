package fr.formation.entity;

import java.util.Date;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "Personne_PK_2")
public class Personne {


	@EmbeddedId
	private PersonnePK pk;
	
	@Temporal(TemporalType.DATE)
	private Date dateDeNaissance;
	

	
	public Personne() {
		pk = new PersonnePK();
	}
	
	
	public Personne(String nom, String prenom, Date dateDeNaissance) {
		pk = new PersonnePK();
		pk.setNom(nom);
		pk.setPrenom(prenom);
		this.dateDeNaissance = dateDeNaissance;
	}


	public String getNom() {
		return pk.getNom();
	}

	public void setNom(String nom) {
		pk.setNom(nom);
	}

	public String getPrenom() {
		return pk.getPrenom();
	}

	public void setPrenom(String prenom) {
		pk.setPrenom(prenom);
	}

	public Date getDateDeNaissance() {
		return dateDeNaissance;
	}

	public void setDateDeNaissance(Date dateDeNaissance) {
		this.dateDeNaissance = dateDeNaissance;
	}


	@Override
	public String toString() {
		return "Personne [nom=" + pk.getNom() + ", prenom=" + pk.getNom() + ", dateDeNaissance=" + dateDeNaissance
				+ "]";
	}
	
	
	
}
