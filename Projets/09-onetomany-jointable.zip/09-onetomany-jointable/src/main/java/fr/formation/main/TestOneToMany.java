package fr.formation.main;

import java.util.ArrayList;
import java.util.List;

import fr.formation.dao.EntrepriseDao;
import fr.formation.dao.JpaUtil;
import fr.formation.entity.Entreprise;
import fr.formation.entity.Salarie;

public class TestOneToMany {

	public static void main(String[] args) {
		
		
		Salarie s1 = new Salarie("Legrand");
		Salarie s2 = new Salarie("Lepetit");
		List<Salarie> liste1 = new ArrayList<Salarie>();
		liste1.add(s1);
		liste1.add(s2);
		Entreprise e1 = new Entreprise("Sopra", liste1);

		Salarie s3 = new Salarie("Lebleu");
		Salarie s4 = new Salarie("Lerouge");
		Salarie s5 = new Salarie("Levert");
		List<Salarie> liste2 = new ArrayList<Salarie>();
		liste2.add(s3);
		liste2.add(s4);
		liste2.add(s5);
		Entreprise e2 = new Entreprise("CGI", liste2);

		EntrepriseDao dao = new EntrepriseDao();
		
		dao.add(e1);
		dao.add(e2);
		
		List<Entreprise> listeE = dao.findAll();
		listeE.forEach(e -> System.out.println(e));
	
		
		JpaUtil.close();
	}

}
