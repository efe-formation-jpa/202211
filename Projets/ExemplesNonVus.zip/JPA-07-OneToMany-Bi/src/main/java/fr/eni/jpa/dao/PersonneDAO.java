package fr.eni.jpa.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import fr.eni.jpa.entity.Personne;
import fr.eni.jpa.exception.DAOException;

public class PersonneDAO {

	
	public static void add(Personne p) throws DAOException{
		EntityManager em = DAOUtil.getEntityManager();
		EntityTransaction et = em.getTransaction();
		et.begin();
		try {
			em.persist(p);
			et.commit();
		} catch (Exception e) {
			et.rollback();
			throw new DAOException("Erreur lors de l'ajout de la personne " 
			+ p + " : " + e.getMessage());
		}
	}
	
	public static void delete(Personne p) throws DAOException{
		EntityManager em = DAOUtil.getEntityManager();
		EntityTransaction et = em.getTransaction();
		p = em.find(Personne.class, p.getId());
		et.begin();
		try {
			em.remove(p);
			et.commit();
		} catch (Exception e) {
			et.rollback();
			throw new DAOException("Erreur lors de la suppression de la personne " 
			+ p + " : " + e.getMessage());
		}
	}
	
	public static void update(Personne p) throws DAOException{
		EntityManager em = DAOUtil.getEntityManager();
		EntityTransaction et = em.getTransaction();
		et.begin();
		try {
			em.merge(p);
			et.commit();
		} catch (Exception e) {
			et.rollback();
			e.printStackTrace();
			throw new DAOException("Erreur lors de la modification de la personne " 
			+ p + " : " + e.getMessage());
		}
	}
	
	public static List<Personne> findAll(){
		String req = "SELECT Object(p) FROM Personne p";
		
		return DAOUtil
				.getEntityManager()
				.createQuery(req, Personne.class)
				.getResultList();
	}



	
	public static Personne findById(int id){
		return DAOUtil
				.getEntityManager()
				.find(Personne.class, id);
	}

	
	
	
}
