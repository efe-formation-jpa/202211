package fr.eni.jpa.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="PersonneOTMBi")
public class Personne implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	
	private String nom;
	private String prenom;
	
	@OneToMany(cascade=CascadeType.ALL, orphanRemoval=true, mappedBy="personne")
	private List<Adresse> listeAdresses;

	public Personne() {
		setListeAdresses(null);
	}
	
	public Personne(String nom, String prenom, List<Adresse> listeAdresses) {
		this.nom = nom;
		this.prenom = prenom;
		setListeAdresses(listeAdresses);
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public List<Adresse> getListeAdresses() {
		return listeAdresses;
	}

	public void setListeAdresses(List<Adresse> listeAdresses) {
		if (listeAdresses != null){
			this.listeAdresses = listeAdresses;
			
			for (Adresse adresse : this.listeAdresses) {
				adresse.setPersonne(this);
			}
		}
		else
			this.listeAdresses = new ArrayList<>();
	}

	@Override
	public String toString() {
		return "Personne [id=" + id + ", nom=" + nom + ", prenom=" + prenom + ", listeAdresses=" + listeAdresses + "]";
	}

	

}
