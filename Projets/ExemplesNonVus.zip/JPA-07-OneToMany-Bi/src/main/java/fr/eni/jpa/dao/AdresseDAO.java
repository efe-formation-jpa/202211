package fr.eni.jpa.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import fr.eni.jpa.entity.Adresse;
import fr.eni.jpa.exception.DAOException;

public class AdresseDAO {

	
	public static void add(Adresse a) throws DAOException{
		EntityManager em = DAOUtil.getEntityManager();
		EntityTransaction et = em.getTransaction();
		et.begin();
		try {
			em.persist(a);
			et.commit();
		} catch (Exception e) {
			et.rollback();
			throw new DAOException("Erreur lors de l'ajout de la Adresse " 
			+ a + " : " + e.getMessage());
		}
	}
	
	public static void delete(Adresse a) throws DAOException{
		EntityManager em = DAOUtil.getEntityManager();
		EntityTransaction et = em.getTransaction();
		et.begin();
		try {
			em.remove(a);
			et.commit();
		} catch (Exception e) {
			et.rollback();
			throw new DAOException("Erreur lors de la suppression de la Adresse " 
			+ a + " : " + e.getMessage());
		}
	}
	
	public static void update(Adresse a) throws DAOException{
		EntityManager em = DAOUtil.getEntityManager();
		EntityTransaction et = em.getTransaction();
		et.begin();
		try {
			em.merge(a);
			et.commit();
		} catch (Exception e) {
			et.rollback();
			e.printStackTrace();
			throw new DAOException("Erreur lors de la modification de la Adresse " 
			+ a + " : " + e.getMessage());
		}
	}
	
	public static List<Adresse> findAll(){
		String req = "SELECT Object(a) FROM Adresse a";
		
		return DAOUtil
				.getEntityManager()
				.createQuery(req, Adresse.class)
				.getResultList();
	}



	
	public static Adresse findById(int id){
		return DAOUtil
				.getEntityManager()
				.find(Adresse.class, id);
	}

	
	
	
}
