package fr.eni.jpa.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import fr.eni.jpa.entity.Personne;

public class PersonneDAO {

	public static Personne findById(int id){
		return DAOUtil.getEntityManager().find(Personne.class, id);
	}

	public static List<Personne> findAll(){
		String requete = "select Object(p) from Personne p";
		return DAOUtil.getEntityManager().createQuery(requete).getResultList();
	}

	public static void add(Personne p) throws Exception{
		EntityManager em = DAOUtil.getEntityManager();
		EntityTransaction et = em.getTransaction();
		et.begin();
		try {
			em.persist(p);
			et.commit();
		} catch (Exception e) {
			et.rollback();
			throw e;
		}
	}
	public static void delete(Personne p) throws Exception{
		EntityManager em = DAOUtil.getEntityManager();
		EntityTransaction et = em.getTransaction();
		p = em.find(Personne.class, p.getId());
		try {
			et.begin();
			em.remove(p);
			et.commit();
		} catch (Exception e) {
			et.rollback();
			throw e;
		}
	}

	
	public static void update(Personne p) throws Exception{
		try {
			DAOUtil.getEntityManager().getTransaction().begin();
			DAOUtil.getEntityManager().merge(p);
			DAOUtil.getEntityManager().getTransaction().commit();
		} catch (Exception e) {
			DAOUtil.getEntityManager().getTransaction().rollback();
			throw e;
		}
		
	}
}
