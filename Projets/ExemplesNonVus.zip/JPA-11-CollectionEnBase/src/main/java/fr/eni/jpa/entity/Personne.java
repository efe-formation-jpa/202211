	package fr.eni.jpa.entity;
	
	import java.io.Serializable;
	import java.util.ArrayList;
	import java.util.List;
	
	import javax.persistence.CollectionTable;
	import javax.persistence.Column;
	import javax.persistence.ElementCollection;
	import javax.persistence.Entity;
	import javax.persistence.ForeignKey;
	import javax.persistence.GeneratedValue;
	import javax.persistence.GenerationType;
	import javax.persistence.Id;
	import javax.persistence.JoinColumn;
	import javax.persistence.Table;
	
	@Entity
	@Table(name = "PersonneCollection")
	public class Personne implements Serializable{
	
		private static final long serialVersionUID = 1L;
	
		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		private int id;
	
		private String nom;
		private String prenom;
	
		@ElementCollection
		@CollectionTable(	name = "Sports", 
							joinColumns= 
								@JoinColumn(name="id_spo", referencedColumnName="id"))
		@Column(name = "sport")
		List<String> sports;
	
	
		public Personne(String nom, String prenom, List<String> sports) {
			this.nom = nom;
			this.prenom = prenom;
			this.sports = sports;
		}
	
		public Personne() {
			setSports(null);
		}
	
		
		public int getId() {
			return id;
		}
	
		public void setId(int id) {
			this.id = id;
		}
	
		public String getNom() {
			return nom;
		}
	
		public void setNom(String nom) {
			this.nom = nom;
		}
	
		public String getPrenom() {
			return prenom;
		}
	
		public void setPrenom(String prenom) {
			this.prenom = prenom;
		}
	
		public List<String> getSports() {
			return sports;
		}
	
		public void setSports(List<String> sports) {
			if (sports != null)
				this.sports = sports;
			else
				this.sports = new ArrayList<>();
		}
		
		
		
		
	}
