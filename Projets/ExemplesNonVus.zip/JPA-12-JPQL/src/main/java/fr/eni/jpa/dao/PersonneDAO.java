package fr.eni.jpa.dao;

import java.util.List;

import javax.persistence.Cache;
import javax.persistence.CacheRetrieveMode;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.hibernate.jpa.QueryHints;

import fr.eni.jpa.entity.Personne;
import fr.eni.jpa.exception.DAOException;

public class PersonneDAO {

	public static void add(Personne p) throws DAOException {
		EntityManager em = DAOUtil.getEntityManager();
		EntityTransaction et = em.getTransaction();
		et.begin();
		try {
			em.persist(p);
			et.commit();
		} catch (Exception e) {
			et.rollback();
			throw new DAOException("Erreur lors de l'ajout de la personne " + p + " : " + e.getMessage());
		}
	}

	public static void deleteAll() throws DAOException {
		String req = "DELETE FROM Personne p";
		EntityManager em = DAOUtil.getEntityManager();
		EntityTransaction et = em.getTransaction();
		et.begin();
		try {
			em.createQuery(req).executeUpdate();
			et.commit();
		} catch (Exception e) {
			et.rollback();
			throw new DAOException("Erreur lors de la suppression de toutes les personnes " + " : " + e.getMessage());
		}
	}

	public static void delete(Personne p) throws DAOException {
		EntityManager em = DAOUtil.getEntityManager();
		EntityTransaction et = em.getTransaction();
		et.begin();
		try {
			em.remove(p);
			et.commit();
		} catch (Exception e) {
			et.rollback();
			throw new DAOException("Erreur lors de la suppression de la personne " + p + " : " + e.getMessage());
		}
	}

	public static void update(Personne p) throws DAOException {
		EntityManager em = DAOUtil.getEntityManager();
		EntityTransaction et = em.getTransaction();
		et.begin();
		try {
			em.merge(p);
			et.commit();
		} catch (Exception e) {
			et.rollback();
			throw new DAOException("Erreur lors de la modification de la personne " + p + " : " + e.getMessage());
		}
	}

	public static List<Personne> findAll() {
		String req = "SELECT Object(p) FROM Personne p";

		return DAOUtil.getEntityManager().createQuery(req, Personne.class).getResultList();
	}

	public static Personne findById(int id) {
		return DAOUtil.getEntityManager().find(Personne.class, id);
	}

	public static List<Personne> findTous() {
		TypedQuery<Personne> query = DAOUtil.getEntityManager().createNamedQuery("findTous", Personne.class);
		return query.getResultList();
	}

	public static List<Personne> findNomCommencePar(String debut) {
		TypedQuery<Personne> query = DAOUtil.getEntityManager().createNamedQuery("findNomCommencePar", Personne.class);

		return query.setParameter("var", debut + "%").getResultList();
	}

	public static List<Personne> findMessieurs() {
		TypedQuery<Personne> query = DAOUtil.getEntityManager().createNamedQuery("findMessieurs", Personne.class);

		return query.getResultList();
	}

	public static List<Personne> findLegrand() {
		EntityManager em = DAOUtil.getEntityManager();

		Query query = em.createQuery("SELECT p FROM Personne p WHERE p.nom = 'Legrand'");

		return query.getResultList();
	}

	public static List<Personne> findLepetit() {
		EntityManager em = DAOUtil.getEntityManager();

		TypedQuery<Personne> query = em.createQuery("SELECT p FROM Personne p WHERE p.nom = 'Lepetit'", Personne.class);

		return query.getResultList();
	}

	public static List<Personne> findByNom(String nom) {
		EntityManager em = DAOUtil.getEntityManager();

		TypedQuery<Personne> query = em.createQuery("SELECT p FROM Personne p WHERE p.nom = :nom", Personne.class);
		query.setParameter("nom", nom);

		return query.getResultList();
	}

	public static List<Personne> findByNom2(String nom) {
		EntityManager em = DAOUtil.getEntityManager();

		TypedQuery<Personne> query = em.createQuery("SELECT p FROM Personne p WHERE p.nom = ?1", Personne.class);
		query.setParameter(1, nom);

		return query.getResultList();
	}

	public static Personne findByIdQuery(int id) {
		EntityManager em = DAOUtil.getEntityManager();

		TypedQuery<Personne> query = em.createQuery("SELECT p FROM Personne p WHERE p.id = :id", Personne.class);
		query.setParameter("id", 120);
		Personne pers = null;
		
		try{
			pers = query.getSingleResult();
		}
		catch (Exception e) {
		}
		return pers;
	}

	public static long nombreDElements() {
		EntityManager em = DAOUtil.getEntityManager();

		TypedQuery<Long> query = em.createQuery("SELECT COUNT(p.id) FROM Personne p", Long.class);

		return query.getSingleResult();
	}

	public static List<String> tousLesPrenom() {
		EntityManager em = DAOUtil.getEntityManager();

		TypedQuery<String> query = em.createQuery("SELECT p.prenom FROM Personne p", String.class);

		return query.getResultList();
	}

	public static List<Personne> jointure() {
		EntityManager em = DAOUtil.getEntityManager();

		TypedQuery<Personne> query = em.createQuery("SELECT p FROM Personne p JOIN p.civilite c WHERE c.cle='Mlle'",
				Personne.class);

		return query.getResultList();
	}

	public static List<Personne> jointureAvecTri() {
		EntityManager em = DAOUtil.getEntityManager();

		TypedQuery<Personne> query = em.createQuery("SELECT p FROM Personne p JOIN p.civilite c ORDER BY c.libelle",
				Personne.class);
		
		return query.getResultList();
	}

	public static void suppressionLegrand() throws DAOException {
		EntityManager em = DAOUtil.getEntityManager();
		EntityTransaction et = em.getTransaction();
		Query query = em.createQuery("DELETE FROM Personne p WHERE p.nom = 'Legrand'");

		et.begin();
		try {
			query.executeUpdate();
			et.commit();
		} catch (Exception e) {
			et.rollback();
			throw new DAOException("Erreur lors de la suppression des Legrand " + " : " + e.getMessage());
		}
	}


	public static void modifier(int id, String newPrenom) throws DAOException {
		EntityManager em = DAOUtil.getEntityManager();
		EntityTransaction et = em.getTransaction();
		Query query = em.createQuery("UPDATE Personne p SET p.prenom = :prenom WHERE p.id = :id");
		query.setParameter("id", id);
		query.setParameter("prenom", newPrenom);
		et.begin();
		try {
			query.executeUpdate();
			et.commit();
		} catch (Exception e) {
			et.rollback();
			throw new DAOException("Erreur lors de la modification " + " : " + e.getMessage());
		}
	}

	
}
