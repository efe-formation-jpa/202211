package fr.eni.jpa.main;

import fr.eni.jpa.dao.CiviliteDAO;
import fr.eni.jpa.dao.DAOUtil;
import fr.eni.jpa.entity.Civilite;

public class MainCivilite {

	public static void main(String[] args) {

		Civilite c1 = new Civilite("M", "Monsieur");
		Civilite c2 = new Civilite("Mlle", "Mademoiselle");
		Civilite c3 = new Civilite("Mme", "Madame");
		
		try {
			CiviliteDAO.add(c1);
			CiviliteDAO.add(c2);
			CiviliteDAO.add(c3);
			System.out.println("OK");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		DAOUtil.close();
	}

}
