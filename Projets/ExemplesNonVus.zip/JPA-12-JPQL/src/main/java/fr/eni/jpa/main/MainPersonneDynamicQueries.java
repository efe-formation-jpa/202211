package fr.eni.jpa.main;

import java.util.List;

import javax.persistence.NoResultException;

import fr.eni.jpa.dao.CiviliteDAO;
import fr.eni.jpa.dao.DAOUtil;
import fr.eni.jpa.dao.PersonneDAO;
import fr.eni.jpa.entity.Civilite;
import fr.eni.jpa.entity.Personne;
import fr.eni.jpa.exception.DAOException;

public class MainPersonneDynamicQueries {

	public static void main(String[] args) {
		List<Personne> listeP;

		try {
			PersonneDAO.deleteAll();
		} catch (DAOException e1) {
			e1.printStackTrace();
		}

		Civilite mlle = CiviliteDAO.findById("Mlle");
		Civilite mme = CiviliteDAO.findById("Mme");
		Civilite m = CiviliteDAO.findById("M");

		System.out.println(mlle);
		System.out.println(mme);
		System.out.println(m);

		Personne p1 = new Personne("N10", "P1", m);
		Personne p2 = new Personne("N20", "P2", mlle);
		Personne p3 = new Personne("N30", "P3", mme);
		Personne p4 = new Personne("N14", "P4", mme);
		Personne p5 = new Personne("N50", "P5", mlle);
		Personne p6 = new Personne("N16", "P6", m);
		Personne p7 = new Personne("N17", "P7", mme);
		Personne p8 = new Personne("Legrand", "Aline", mme);
		Personne p9 = new Personne("Lepetit", "Lucie", mlle);

		try {
			PersonneDAO.add(p1);
			PersonneDAO.add(p2);
			PersonneDAO.add(p3);
			PersonneDAO.add(p4);
			PersonneDAO.add(p5);
			PersonneDAO.add(p6);
			PersonneDAO.add(p7);
			PersonneDAO.add(p8);
			PersonneDAO.add(p9);
		} catch (Exception e) {
			e.printStackTrace();
		}

		// System.out.println("\nTous les Legrand");
		// listeP = PersonneDAO.findLegrand();
		// for (Personne p : listeP) {
		// System.out.println(p);
		// }
		//
		// System.out.println("\nTous les Lepetit");
		// listeP = PersonneDAO.findLepetit();
		// for (Personne p : listeP) {
		// System.out.println(p);
		// }

		// System.out.println("\nTous les Lepetit");
		// listeP = PersonneDAO.findByNom("Lepetit");
		// for (Personne p : listeP) {
		// System.out.println(p);
		// }

//		System.out.println("\nTous les Legrand");
//		listeP = PersonneDAO.findByNom2("Legrand");
//		for (Personne p : listeP) {
//			System.out.println(p);
//		}
//
//		try {
//			System.out.println("\nLe 120 : " + PersonneDAO.findByIdQuery(120));
//
//		} catch (NoResultException e) {
//			System.out.println("\nPas de 120");
//		}
//		System.out.println("Nombre de personnes : " + PersonneDAO.nombreDElements());
//
//		System.out.println("\nTous les prénoms");
//		List<String> listeS = PersonneDAO.tousLesPrenom();
//		for (String string : listeS) {
//			System.out.println(string);
//		}
		
		System.out.println("\nSuppression de s Legrand");
		try {
			PersonneDAO.suppressionLegrand();
		} catch (DAOException e) {
			e.printStackTrace();
		}

		System.out.println("\nModification du 209");
		try {
			PersonneDAO.modifier(281, "Marc");
		} catch (DAOException e) {
			e.printStackTrace();
		}

		
		System.out.println("\nTri par civilite");
		listeP = PersonneDAO.jointureAvecTri();
		for (Personne p : listeP) {
			System.out.println(p);
		}
		
		
		DAOUtil.close();
	}

}
