package fr.formation.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import fr.formation.dao.PersonneDao;
import fr.formation.entity.Personne;

@Service
public class PersonneService {

	@Autowired
	private PersonneDao dao;
	
	public void ajouterPersonne(Personne p) {
		dao.save(p);
	}
	
	public List<Personne> listePersonnesTrieeParNom() {
		return dao.findByOrderByNom();
	}
	
	public List<Personne> listePersonnesParNom(String nom) {
		return dao.findByNomContaining(nom);
	}
}
