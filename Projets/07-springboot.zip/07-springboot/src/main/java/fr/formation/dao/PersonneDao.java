package fr.formation.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import fr.formation.entity.Personne;

public interface PersonneDao extends JpaRepository<Personne, Integer> {
	
	List<Personne> findByOrderByNom();
	List<Personne> findByNomContaining(String nom);

	List<Personne> findByAdresseVille(String ville);
}
