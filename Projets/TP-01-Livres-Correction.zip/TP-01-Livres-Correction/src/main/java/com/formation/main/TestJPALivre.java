package com.formation.main;

import java.util.List;

import com.formation.bean.Livre;
import com.formation.dao.JpaUtil;
import com.formation.dao.LivreDAO;
import com.formation.exception.DAOException;

public class TestJPALivre {

	
	
	
	public static void main(String[] args) {
		Livre l1 = new Livre("La b H", "E Zola", 450);
		Livre l2 = new Livre("Huis Clos", "JP Sartre", 350);
		Livre l3 = new Livre("L'Etranger", "Albert Camus", 476);
		Livre l4 = new Livre("La Peste", "Albert Camus", 359);
		
		LivreDAO lDao = new LivreDAO();
		
		
		try {
			lDao.add(l1);
			lDao.add(l2);
			lDao.add(l3);
			lDao.add(l4);
		} catch (DAOException e) {
			System.out.println(e.getMessage());
		}
		
		System.out.println("\nCréation de 4 livres");
		
		List<Livre> listeL = lDao.findAll();
		
		affiche(listeL, "Liste des livres");
		affiche(lDao.findAllOrderByTitreAsc(),  "Liste des livres tries par titre ascendant");
		affiche(lDao.findAllOrderByTitreDesc(),  "Liste des livres tries par titre descendant");
		affiche(lDao.findByAuteurLike("Camus"), "Livres de Camus");
		System.out.println("1er id : " + lDao.getMinId());
		System.out.println("dernier id : " + lDao.getMaxId());
		
		System.out.println("Livre id =  2 : " + lDao.findById(2));
		System.out.println("Livre id = 22 : " + lDao.findById(22));
		
		try {
			lDao.delete(l1);
		} catch (DAOException e) {
			System.out.println(e.getMessage());
		}
		
		try {
			lDao.delete(3);
		} catch (DAOException e) {
			System.out.println(e.getMessage());
		}
		
		l2.setAuteur("Jean-Paul Sartre");
		l2.setNbPages(1001);
		
		try {
			lDao.update(l2);
		} catch (DAOException e) {
			System.out.println(e.getMessage());
		}
		
		affiche(lDao.findAll(), "Liste des livres après modifs et suppressions");
		
		JpaUtil.close();
		
	}

	private static void affiche(List<Livre> listeL, String msg) {
		System.out.println();
		System.out.println(msg);
		for (Livre livre : listeL) {
			System.out.println(livre);
		}
	}

}
