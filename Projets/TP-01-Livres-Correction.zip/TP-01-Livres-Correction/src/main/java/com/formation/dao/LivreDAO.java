package com.formation.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;

import com.formation.bean.Livre;
import com.formation.exception.DAOException;

public class LivreDAO {

	
	public Livre findById(int id) {
		EntityManager em = JpaUtil.getEntityManager();
		Livre l = em.find(Livre.class, id);
		em.close();
		return l;
	}
	
	public Livre findById2(int id) {
		EntityManager em = JpaUtil.getEntityManager();
		String req = "select Object(l) from Livre l where id = :id";
		Livre l = null;
		try {
			l = (Livre) em.createQuery(req).setParameter("id", id).getSingleResult();
		} catch (NoResultException e) {
		}
		em.close();
		
		return l;
	}
	
	public List<Livre> findAll(){
		List<Livre> listeL = null;
		String req = "select Object(l) from Livre l";
		listeL = JpaUtil.getEntityManager().createQuery(req, Livre.class).getResultList();
		return listeL;
 	}
	
	public List<Livre> findAllOrderByTitreAsc(){
		List<Livre> listeL = null;
		String req = "select Object(l) from Livre l order by l.titre asc";
		listeL = JpaUtil.getEntityManager().createQuery(req, Livre.class).getResultList();
		return listeL;
 	}
	
	public List<Livre> findAllOrderByTitreDesc(){
		List<Livre> listeL = null;
		String req = "select Object(l) from Livre l order by l.titre desc";
		listeL = JpaUtil.getEntityManager().createQuery(req, Livre.class).getResultList();
		return listeL;
 	}
	
	public List<Livre> findByAuteurLike(String aut){
		List<Livre> listeL = null;
		String req = "select Object(l) from Livre l where l.auteur like :var";
		listeL = JpaUtil
					.getEntityManager()
					.createQuery(req, Livre.class)
					.setParameter("var", "%"+aut+"%")
					.getResultList();
		return listeL;
 	}
	
	
	public int getMaxId() {
		String req = "Select Max(l.id) from Livre l";
		int res =  (int) JpaUtil.getEntityManager().createQuery(req).getSingleResult();
		return res;
	}
	
	public int getMinId() {
		String req = "Select Min(l.id) from Livre l";
		int res =  (int) JpaUtil.getEntityManager().createQuery(req).getSingleResult();
		return res;
	}
	
	public void add(Livre l) throws DAOException{
		EntityManager em = JpaUtil.getEntityManager();
		EntityTransaction et = em.getTransaction();
		
		et.begin();
		try {
			em.persist(l);
			et.commit();
		} catch (Exception e) {
			et.rollback();
			throw new DAOException("Une erreur s'est produite lors de l'ajout du livre " + l);
		}
		
	}
	
	
	public void delete(Livre l) throws DAOException{
		EntityManager em = JpaUtil.getEntityManager();
		EntityTransaction et = em.getTransaction();
		l = em.find(Livre.class, l.getId());
		et.begin();
		try {
			em.remove(l);
			et.commit();
		} catch (Exception e) {
			et.rollback();
			throw new DAOException("Une erreur s'est produite lors de la suppression du livre " + l + " : "+ e.getMessage());
		}
	}
	
	
	
	public void delete(int id) throws DAOException{
		Livre l = findById(id);
		delete(l);
	}
	
	
	
	
	public void update(Livre l) throws DAOException{
		EntityManager em = JpaUtil.getEntityManager();
		EntityTransaction et = em.getTransaction();
		
		et.begin();
		try {
			em.merge(l);
			et.commit();
		} catch (Exception e) {
			et.rollback();
			throw new DAOException("Une erreur s'est produite lors de la modificationa du livre " + l);
		}
	}

}
