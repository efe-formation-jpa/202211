package fr.formation.main;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import fr.formation.entity.Personne;

public class AppelPersonne {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("H2_PU");
		EntityManager em = emf.createEntityManager();
		
		Personne p1 = new Personne("Legrand", "Lucie", new Date(122, 5, 1));
		Personne p2 = new Personne("Lepetit", "Joe", null);
		Personne p3 = new Personne("Lemoyen", "Marie", new Date(100, 6, 14));
		
		EntityTransaction et = em.getTransaction();
		et.begin();
		
		try {
			em.persist(p1);
			em.persist(p2);
			em.persist(p3);
			et.commit();
		} catch (Exception e) {
			e.printStackTrace();
			et.rollback();
		}
		
		String requete = "From Personne p";
	
		List<Personne> listeP = em .createQuery(requete, Personne.class).getResultList();
		System.out.println("Liste des personnes en base : ");
		
		listeP.forEach(p -> System.out.println(p));
		
		System.out.println("\nListe des noms des personnes en base : ");
		requete = "Select p.nom From Personne p";
		List<String> listeS = em.createQuery(requete, String.class).getResultList();
		listeS.forEach(s -> System.out.println(s));
		
		em.close();
		emf.close();
	}
}
