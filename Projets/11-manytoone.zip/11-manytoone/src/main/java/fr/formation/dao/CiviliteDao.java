package fr.formation.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import fr.formation.entity.Civilite;


public class CiviliteDao {

	public void add(Civilite c) {
		EntityManager em = JpaUtil.getEntityManager();
		EntityTransaction et = em.getTransaction();
		
		et.begin();
		
		try {
			em.persist(c);
			et.commit();
		} catch (Exception e) {
			et.rollback();
			e.printStackTrace();
		}
	}
	
	
	public Civilite findById(String cle) {
		return JpaUtil
				.getEntityManager()
				.find(Civilite.class, cle);
	}
	
	
	public List<Civilite> findAll() {
		EntityManager em = JpaUtil.getEntityManager();
		return em
				.createQuery("From Civilite", Civilite.class)
				.getResultList();
	}
	
}
