package fr.formation.main;

import java.util.List;

import fr.formation.dao.CiviliteDao;
import fr.formation.dao.JpaUtil;
import fr.formation.dao.PersonneDao;
import fr.formation.entity.Civilite;
import fr.formation.entity.Personne;

public class ManagePersonnes {

	public static void main(String[] args) {
		
		CiviliteDao civiliteDao = new CiviliteDao();
		
		Civilite m = civiliteDao.findById("M");
		Civilite mlle = civiliteDao.findById("Mlle");
		Civilite mme = civiliteDao.findById("Mme");
		
		// Supprimer toutes les personnes
		PersonneDao personneDao = new PersonneDao();
		
		personneDao.supprimerTous();
		
		System.out.println(m);
		System.out.println(mme);
		System.out.println(mlle);
		
		Personne p1 = new Personne("Legrand", mme);
		Personne p2 = new Personne("Lepetit", m);
		Personne p3 = new Personne("Lemoyen", mlle);
		Personne p4 = new Personne("Letresgrand", mlle);
		
		personneDao.add(p1);
		personneDao.add(p2);
		personneDao.add(p3);
		personneDao.add(p4);
		
		List<Personne> listeP = personneDao.findAll();
		listeP.forEach(p -> System.out.println(p));
		
		JpaUtil.close();
	}
}
