package fr.formation.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import fr.formation.entity.Personne;


public class PersonneDao {

	public void add(Personne p) {
		EntityManager em = JpaUtil.getEntityManager();
		EntityTransaction et = em.getTransaction();
		
		et.begin();
		
		try {
			em.persist(p);
			et.commit();
		} catch (Exception e) {
			et.rollback();
			e.printStackTrace();
		}
	}
	
	

	
	public List<Personne> findAll() {
		EntityManager em = JpaUtil.getEntityManager();
		return em
				.createQuery("From Personne", Personne.class)
				.getResultList();
	}




	public void supprimerTous() {
		String requete = "Delete From Personne p";
		EntityManager em = JpaUtil.getEntityManager();
		EntityTransaction et = em.getTransaction();
		
		et.begin();
		try {
			em.createQuery(requete).executeUpdate();
			et.commit();
		} catch (Exception e) {
			et.rollback();
			e.printStackTrace();
		}
		
	}
	
}
