package fr.formation.main;

import fr.formation.dao.CiviliteDao;
import fr.formation.dao.JpaUtil;
import fr.formation.entity.Civilite;

public class ManageCivilites {

	public static void main(String[] args) {
		
		Civilite c1 = new Civilite("Mlle", "Mademoiselle");
		Civilite c2 = new Civilite("Mme", "Madame");
		Civilite c3 = new Civilite("M", "Monsieur");

		CiviliteDao cDao = new CiviliteDao();
		cDao.add(c1);
		cDao.add(c2);
		cDao.add(c3);
		
		
		JpaUtil.close();
	}

}
