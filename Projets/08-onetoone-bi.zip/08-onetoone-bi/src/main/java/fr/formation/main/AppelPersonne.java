package fr.formation.main;

import java.util.List;

import fr.formation.dao.AdresseDao;
import fr.formation.dao.JpaUtil;
import fr.formation.dao.PersonneDao;
import fr.formation.entity.Adresse;
import fr.formation.entity.Personne;

public class AppelPersonne {

	public static void main(String[] args) {
		
		Adresse a1 = new Adresse("44000", "Nantes");
		Adresse a2 = new Adresse("75001", "Paris");
		
		Personne p1 = new Personne("Lebleu", "Suzon", a1);
		Personne p2 = new Personne("Levert", "Aline", a2);
		
		
		PersonneDao pDao = new PersonneDao();
		pDao.add(p1);
		pDao.add(p2);
		
		List<Personne> listeP = pDao.findAll();
		System.out.println("\nListe des personnes en base :");
		listeP.forEach(p -> System.out.println(p));
	
		AdresseDao adresseDao = new AdresseDao();
		adresseDao.delete(a1);
		
		listeP = pDao.findAll();
		System.out.println("\nListe des personnes en base apres suppression d'une adresse :");
		listeP.forEach(p -> System.out.println(p));
		
		JpaUtil.close();
	}
}
