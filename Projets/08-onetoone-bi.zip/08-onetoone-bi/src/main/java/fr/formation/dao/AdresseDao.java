package fr.formation.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import fr.formation.entity.Adresse;
import fr.formation.entity.Personne;

public class AdresseDao {

	public AdresseDao() {
		
	}
	
	public void add(Adresse a) {
		EntityManager em = JpaUtil.getEntityManager();
		EntityTransaction et = em.getTransaction();
		
		et.begin();
		
		try {
			em.persist(a);
			et.commit();
		} catch (Exception e) {
			et.rollback();
			e.printStackTrace();
		}
	}
	
	public void update(Adresse a) {
		EntityManager em = JpaUtil.getEntityManager();
		EntityTransaction et = em.getTransaction();
		
		et.begin();
		
		try {
			em.merge(a);
			et.commit();
		} catch (Exception e) {
			et.rollback();
			e.printStackTrace();
		}
		
	}
	
	public void delete(Adresse a) {
		EntityManager em = JpaUtil.getEntityManager();
		EntityTransaction et = em.getTransaction();
		
		et.begin();
		
		try {
			em.remove(a);
			et.commit();
		} catch (Exception e) {
			et.rollback();
			e.printStackTrace();
		}

	}
	
	public Adresse findById(int id) {
		EntityManager em = JpaUtil.getEntityManager();
		return em.find(Adresse.class, id);
	}
	
	public List<Adresse> findAll() {
		EntityManager em = JpaUtil.getEntityManager();
		return em
				.createQuery("From Adresse", Adresse.class)
				.getResultList();
	}
	
}
