package fr.formation.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import fr.formation.entity.Entreprise;


public class EntrepriseDao {

	public void add(Entreprise entreprise) {
		EntityManager em = JpaUtil.getEntityManager();
		EntityTransaction et = em.getTransaction();
		
		et.begin();
		
		try {
			em.persist(entreprise);
			et.commit();
		} catch (Exception e) {
			et.rollback();
			e.printStackTrace();
		}
	}
	
	

	public void update(Entreprise entreprise) {
		EntityManager em = JpaUtil.getEntityManager();
		EntityTransaction et = em.getTransaction();
		
		et.begin();
		
		try {
			em.merge(entreprise);
			et.commit();
		} catch (Exception e) {
			et.rollback();
			e.printStackTrace();
		}
	}
	
	

	public void delete(Entreprise entreprise) {
		EntityManager em = JpaUtil.getEntityManager();
		EntityTransaction et = em.getTransaction();
		
		et.begin();
		
		try {
			em.remove(entreprise);
			et.commit();
		} catch (Exception e) {
			et.rollback();
			e.printStackTrace();
		}
	}
	
	
	
	public List<Entreprise> findAll() {
		EntityManager em = JpaUtil.getEntityManager();
		return em
				.createQuery("From Entreprise", Entreprise.class)
				.getResultList();
	}
	
}
