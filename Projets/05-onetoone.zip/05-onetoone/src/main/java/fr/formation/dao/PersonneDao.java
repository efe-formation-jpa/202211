package fr.formation.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import fr.formation.entity.Adresse;
import fr.formation.entity.Personne;

public class PersonneDao {

	public PersonneDao() {
		
	}
	
	public void add(Personne p) {
		EntityManager em = JpaUtil.getEntityManager();
		EntityTransaction et = em.getTransaction();
		
		et.begin();
		
		try {
			em.persist(p);
			et.commit();
		} catch (Exception e) {
			et.rollback();
			e.printStackTrace();
		}
	}
	
	public void update(Personne p) {
		EntityManager em = JpaUtil.getEntityManager();
		EntityTransaction et = em.getTransaction();
		
		et.begin();
		
		try {
			em.merge(p);
			et.commit();
		} catch (Exception e) {
			et.rollback();
			e.printStackTrace();
		}
		
	}
	
	public void delete(Personne p) {
		EntityManager em = JpaUtil.getEntityManager();
		EntityTransaction et = em.getTransaction();
		
		et.begin();
		
		try {
			em.remove(p);
			et.commit();
		} catch (Exception e) {
			et.rollback();
			e.printStackTrace();
		}

	}
	
	public Personne findById(int id) {
		EntityManager em = JpaUtil.getEntityManager();
		return em.find(Personne.class, id);
	}
	
	public List<Personne> findAll() {
		EntityManager em = JpaUtil.getEntityManager();
		return em
				.createQuery("From Personne", Personne.class)
				.getResultList();
	}
	
	public List<Adresse> findAllAdresses() {
		EntityManager em = JpaUtil.getEntityManager();
		return em
				.createQuery("Select p.adresse From Personne p", Adresse.class)
				.getResultList();
	}
}
